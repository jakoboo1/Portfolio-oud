<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="cssbpgoeietweedepagina.css" rel="stylesheet">
    <meta charset="UTF-8">
    <title>Persoonlijke web-applicatie</title>
</head>
<body>

<br/>
<br/>
<br/>

<div id="webapp">
    <p>
        Van mijn studie kreeg ik de opdracht om een website te maken waarin mijn persoonlijke portfolio gezet kon worden.  Ik kreeg in de eerste periode lessen over verschillende programmeertalen om op die manier kennis op de te doen. Aan de hand van deze kennis moest ik een webapplicatie maken met de programmeertalen: PHP, CSS, HTML en Javascript.
    </p>
        <br/>
   <br/>
   <br/>

     <H2><U>   DOEL</U> </H2>
    <p>
        Het doel van dit project was om de opgedane kennis in de praktijk toe te passen en op deze manier te laten zien dat jij de gevraagde kennis machtig was.

    </p>


</div>



<div class="kleurgoud">
    <H2><U>   Kleuren </U> </H2>
    <table style="width:60%">
        <tr>

            <th>  <img src="afbeeldingen/Darkgoldenrod.jpg"></th>
            <th><img src="afbeeldingen/lichtgrijs.png"></th>
            <th><img src="afbeeldingen/grijszwart.png"></th>


        </tr>
   <tr>
        <td><h6>#B8860B</h6></td>
        <td><h6>#D3D3D3</h6></td>
        <td><h6>#202425</h6></td>

        </tr>
    </table>
</div>


<div id="downloads">
    <H2><U>Code</U> </H2>
    Hieronder kunt u de code van deze website downloaden

    <br/>

    <button class="buttoncss"><a href="CSS.zip" download> CSS</a>
    <button class="buttonHTML"><a href="html.zip" download> HTML</a>
    <button class="buttonwireframe"><a href="wireframe.xd" download> Wireframe</a>
    
    </div>





<br/>
<br/>
<br/>
<br/>




</body>
</html>